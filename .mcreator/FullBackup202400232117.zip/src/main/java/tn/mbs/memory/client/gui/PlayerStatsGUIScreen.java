package tn.mbs.memory.client.gui;

import tn.mbs.memory.world.inventory.PlayerStatsGUIMenu;
import tn.mbs.memory.procedures.ReturnNextResistanceValueProcedure;
import tn.mbs.memory.procedures.ReturnNextProtectionValueProcedure;
import tn.mbs.memory.procedures.ReturnNextMovementSpeedValueProcedure;
import tn.mbs.memory.procedures.ReturnNextHealthValueProcedure;
import tn.mbs.memory.procedures.ReturnNextExplorationValueProcedure;
import tn.mbs.memory.procedures.ReturnNextAttackSpeedValueProcedure;
import tn.mbs.memory.procedures.ReturnNextAttackPowerValueProcedure;
import tn.mbs.memory.procedures.ReturnExtraPointsProcedure;
import tn.mbs.memory.procedures.ReturnCurrentResistanceProcedure;
import tn.mbs.memory.procedures.ReturnCurrentMovementSpeedProcedure;
import tn.mbs.memory.procedures.ReturnCurrentLevelProcedure;
import tn.mbs.memory.procedures.ReturnCurrentHealthValueProcedure;
import tn.mbs.memory.procedures.ReturnCurrentExplorationProcedure;
import tn.mbs.memory.procedures.ReturnCurrentAttackSpeedProcedure;
import tn.mbs.memory.procedures.ReturnCurrentAttackDamageProcedure;
import tn.mbs.memory.procedures.ReturnCurrentArmorProcedure;
import tn.mbs.memory.procedures.ReturnAttributeTwoTipProcedure;
import tn.mbs.memory.procedures.ReturnAttributeTwoNameProcedure;
import tn.mbs.memory.procedures.ReturnAttributeThreeTipProcedure;
import tn.mbs.memory.procedures.ReturnAttributeThreeNameProcedure;
import tn.mbs.memory.procedures.ReturnAttributeSixthTipProcedure;
import tn.mbs.memory.procedures.ReturnAttributeSixthNameProcedure;
import tn.mbs.memory.procedures.ReturnAttributeSeventhTipProcedure;
import tn.mbs.memory.procedures.ReturnAttributeSeventhNameProcedure;
import tn.mbs.memory.procedures.ReturnAttributeOneTipProcedure;
import tn.mbs.memory.procedures.ReturnAttributeOneNameProcedure;
import tn.mbs.memory.procedures.ReturnAttributeForthTipProcedure;
import tn.mbs.memory.procedures.ReturnAttributeForthNameProcedure;
import tn.mbs.memory.procedures.ReturnAttributeFifthTipProcedure;
import tn.mbs.memory.procedures.ReturnAttributeFifthNameProcedure;
import tn.mbs.memory.procedures.PlayerNameProcedure;
import tn.mbs.memory.procedures.GetThePlayerModelProcedure;
import tn.mbs.memory.procedures.DisplayLevelingLogicProtectionProcedure;
import tn.mbs.memory.procedures.DisplayLevelingLogicMSProcedure;
import tn.mbs.memory.procedures.DisplayLevelingLogicFortitudeProcedure;
import tn.mbs.memory.procedures.DisplayLevelingLogicExplorationProcedure;
import tn.mbs.memory.procedures.DisplayLevelingLogicAttackSpeedProcedure;
import tn.mbs.memory.procedures.DisplayLevelingLogicAttackPowerProcedure;
import tn.mbs.memory.procedures.DisplayLevelingHealthLogicProcedure;
import tn.mbs.memory.network.PlayerStatsGUIButtonMessage;

import org.joml.Vector3f;
import org.joml.Quaternionf;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.GuiGraphics;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class PlayerStatsGUIScreen extends AbstractContainerScreen<PlayerStatsGUIMenu> {
	private final static HashMap<String, Object> guistate = PlayerStatsGUIMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	ImageButton imagebutton_pressed;
	ImageButton imagebutton_pressed3;
	ImageButton imagebutton_pressed1;
	ImageButton imagebutton_pressed2;
	ImageButton imagebutton_pressed4;
	ImageButton imagebutton_pressed5;
	ImageButton imagebutton_pressed6;

	public PlayerStatsGUIScreen(PlayerStatsGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 234;
		this.imageHeight = 166;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics, mouseX, mouseY, partialTicks);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		if (GetThePlayerModelProcedure.execute(world, x, y, z, entity) instanceof LivingEntity livingEntity) {
			this.renderEntityInInventoryFollowsAngle(guiGraphics, this.leftPos + -16, this.topPos + 137, 60, 0f + (float) Math.atan((this.leftPos + -16 - mouseX) / 40.0), (float) Math.atan((this.topPos + 88 - mouseY) / 40.0), livingEntity);
		}
		this.renderTooltip(guiGraphics, mouseX, mouseY);
		if (DisplayLevelingHealthLogicProcedure.execute())
			if (mouseX > leftPos + 39 && mouseX < leftPos + 54 && mouseY > topPos + 16 && mouseY < topPos + 30)
				guiGraphics.renderTooltip(font, Component.literal(ReturnAttributeOneTipProcedure.execute()), mouseX, mouseY);
		if (DisplayLevelingLogicAttackPowerProcedure.execute())
			if (mouseX > leftPos + 38 && mouseX < leftPos + 55 && mouseY > topPos + 35 && mouseY < topPos + 52)
				guiGraphics.renderTooltip(font, Component.literal(ReturnAttributeTwoTipProcedure.execute()), mouseX, mouseY);
		if (DisplayLevelingLogicAttackSpeedProcedure.execute())
			if (mouseX > leftPos + 38 && mouseX < leftPos + 53 && mouseY > topPos + 55 && mouseY < topPos + 72)
				guiGraphics.renderTooltip(font, Component.literal(ReturnAttributeThreeTipProcedure.execute()), mouseX, mouseY);
		if (DisplayLevelingLogicProtectionProcedure.execute())
			if (mouseX > leftPos + 40 && mouseX < leftPos + 55 && mouseY > topPos + 74 && mouseY < topPos + 90)
				guiGraphics.renderTooltip(font, Component.literal(ReturnAttributeForthTipProcedure.execute()), mouseX, mouseY);
		if (DisplayLevelingLogicMSProcedure.execute())
			if (mouseX > leftPos + 40 && mouseX < leftPos + 53 && mouseY > topPos + 94 && mouseY < topPos + 110)
				guiGraphics.renderTooltip(font, Component.literal(ReturnAttributeFifthTipProcedure.execute()), mouseX, mouseY);
		if (DisplayLevelingLogicFortitudeProcedure.execute())
			if (mouseX > leftPos + 39 && mouseX < leftPos + 54 && mouseY > topPos + 114 && mouseY < topPos + 131)
				guiGraphics.renderTooltip(font, Component.literal(ReturnAttributeSixthTipProcedure.execute()), mouseX, mouseY);
		if (DisplayLevelingLogicExplorationProcedure.execute())
			if (mouseX > leftPos + 38 && mouseX < leftPos + 53 && mouseY > topPos + 136 && mouseY < topPos + 152)
				guiGraphics.renderTooltip(font, Component.literal(ReturnAttributeSeventhTipProcedure.execute()), mouseX, mouseY);
		if (mouseX > leftPos + -51 && mouseX < leftPos + -41 && mouseY > topPos + 147 && mouseY < topPos + 157)
			guiGraphics.renderTooltip(font, Component.translatable("gui.memory_of_the_past.player_stats_gui.tooltip_represents_your_overall_progress"), mouseX, mouseY);
		if (mouseX > leftPos + 64 && mouseX < leftPos + 74 && mouseY > topPos + -8 && mouseY < topPos + 2)
			guiGraphics.renderTooltip(font, Component.translatable("gui.memory_of_the_past.player_stats_gui.tooltip_indicates_the_number_of_points_y"), mouseX, mouseY);
		if (DisplayLevelingHealthLogicProcedure.execute())
			if (mouseX > leftPos + 234 && mouseX < leftPos + 254 && mouseY > topPos + 12 && mouseY < topPos + 32)
				guiGraphics.renderTooltip(font, Component.literal(ReturnNextHealthValueProcedure.execute(entity)), mouseX, mouseY);
		if (DisplayLevelingLogicAttackSpeedProcedure.execute())
			if (mouseX > leftPos + 234 && mouseX < leftPos + 254 && mouseY > topPos + 32 && mouseY < topPos + 52)
				guiGraphics.renderTooltip(font, Component.literal(ReturnNextAttackPowerValueProcedure.execute(entity)), mouseX, mouseY);
		if (DisplayLevelingLogicAttackPowerProcedure.execute())
			if (mouseX > leftPos + 234 && mouseX < leftPos + 254 && mouseY > topPos + 52 && mouseY < topPos + 72)
				guiGraphics.renderTooltip(font, Component.literal(ReturnNextAttackSpeedValueProcedure.execute(entity)), mouseX, mouseY);
		if (DisplayLevelingLogicProtectionProcedure.execute())
			if (mouseX > leftPos + 234 && mouseX < leftPos + 254 && mouseY > topPos + 72 && mouseY < topPos + 92)
				guiGraphics.renderTooltip(font, Component.literal(ReturnNextProtectionValueProcedure.execute(entity)), mouseX, mouseY);
		if (DisplayLevelingLogicMSProcedure.execute())
			if (mouseX > leftPos + 234 && mouseX < leftPos + 254 && mouseY > topPos + 92 && mouseY < topPos + 112)
				guiGraphics.renderTooltip(font, Component.literal(ReturnNextMovementSpeedValueProcedure.execute(entity)), mouseX, mouseY);
		if (DisplayLevelingLogicFortitudeProcedure.execute())
			if (mouseX > leftPos + 234 && mouseX < leftPos + 254 && mouseY > topPos + 112 && mouseY < topPos + 132)
				guiGraphics.renderTooltip(font, Component.literal(ReturnNextResistanceValueProcedure.execute(entity)), mouseX, mouseY);
		if (DisplayLevelingLogicExplorationProcedure.execute())
			if (mouseX > leftPos + 234 && mouseX < leftPos + 254 && mouseY > topPos + 137 && mouseY < topPos + 157)
				guiGraphics.renderTooltip(font, Component.literal(ReturnNextExplorationValueProcedure.execute(entity)), mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();

		guiGraphics.blit(ResourceLocation.parse("memory_of_the_past:textures/screens/player_stats_gui.png"), this.leftPos + -66, this.topPos + -18, 0, 0, 350, 200, 350, 200);

		guiGraphics.blit(ResourceLocation.parse("memory_of_the_past:textures/screens/att_1.png"), this.leftPos + 39, this.topPos + 15, 0, 0, 16, 16, 16, 16);

		guiGraphics.blit(ResourceLocation.parse("memory_of_the_past:textures/screens/att_7.png"), this.leftPos + 38, this.topPos + 136, 0, 0, 16, 16, 16, 16);

		guiGraphics.blit(ResourceLocation.parse("memory_of_the_past:textures/screens/att_6.png"), this.leftPos + 38, this.topPos + 114, 0, 0, 16, 16, 16, 16);

		guiGraphics.blit(ResourceLocation.parse("memory_of_the_past:textures/screens/att_5.png"), this.leftPos + 38, this.topPos + 94, 0, 0, 16, 16, 16, 16);

		guiGraphics.blit(ResourceLocation.parse("memory_of_the_past:textures/screens/att_4.png"), this.leftPos + 40, this.topPos + 74, 0, 0, 16, 16, 16, 16);

		guiGraphics.blit(ResourceLocation.parse("memory_of_the_past:textures/screens/att_3.png"), this.leftPos + 38, this.topPos + 55, 0, 0, 16, 16, 16, 16);

		guiGraphics.blit(ResourceLocation.parse("memory_of_the_past:textures/screens/att_2.png"), this.leftPos + 38, this.topPos + 35, 0, 0, 16, 16, 16, 16);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		if (DisplayLevelingHealthLogicProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnAttributeOneNameProcedure.execute(), 59, 17, -1, false);
		if (DisplayLevelingHealthLogicProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnCurrentHealthValueProcedure.execute(entity), 204, 17, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.memory_of_the_past.player_stats_gui.label_level"), -36, 147, -1, false);
		guiGraphics.drawString(this.font,

				ReturnCurrentLevelProcedure.execute(entity), 4, 147, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.memory_of_the_past.player_stats_gui.label_available_points"), 79, -8, -1, false);
		guiGraphics.drawString(this.font,

				ReturnExtraPointsProcedure.execute(entity), 169, -8, -1, false);
		if (DisplayLevelingLogicFortitudeProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnAttributeSixthNameProcedure.execute(), 59, 117, -1, false);
		if (DisplayLevelingLogicFortitudeProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnCurrentResistanceProcedure.execute(entity), 204, 117, -1, false);
		if (DisplayLevelingLogicProtectionProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnAttributeForthNameProcedure.execute(), 59, 77, -1, false);
		if (DisplayLevelingLogicExplorationProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnAttributeSeventhNameProcedure.execute(), 59, 139, -1, false);
		if (DisplayLevelingLogicProtectionProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnCurrentArmorProcedure.execute(entity), 204, 77, -1, false);
		if (DisplayLevelingLogicAttackPowerProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnAttributeTwoNameProcedure.execute(), 59, 37, -1, false);
		if (DisplayLevelingLogicAttackPowerProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnCurrentAttackDamageProcedure.execute(entity), 204, 37, -1, false);
		if (DisplayLevelingLogicMSProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnAttributeFifthNameProcedure.execute(), 59, 97, -1, false);
		if (DisplayLevelingLogicMSProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnCurrentMovementSpeedProcedure.execute(entity), 204, 97, -1, false);
		if (DisplayLevelingLogicAttackSpeedProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnAttributeThreeNameProcedure.execute(), 59, 57, -1, false);
		if (DisplayLevelingLogicAttackSpeedProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnCurrentAttackSpeedProcedure.execute(entity), 204, 57, -1, false);
		if (DisplayLevelingLogicExplorationProcedure.execute())
			guiGraphics.drawString(this.font,

					ReturnCurrentExplorationProcedure.execute(entity), 204, 140, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.memory_of_the_past.player_stats_gui.label_empty7"), 69, -8, -13553359, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.memory_of_the_past.player_stats_gui.label_empty8"), -46, 147, -12829636, false);
		guiGraphics.drawString(this.font,

				PlayerNameProcedure.execute(entity), -40, 3, -1, false);
	}

	@Override
	public void init() {
		super.init();
		imagebutton_pressed = new ImageButton(this.leftPos + 234, this.topPos + 12, 20, 20,
				new WidgetSprites(ResourceLocation.parse("memory_of_the_past:textures/screens/pressed.png"), ResourceLocation.parse("memory_of_the_past:textures/screens/unpressed.png")), e -> {
					if (DisplayLevelingHealthLogicProcedure.execute()) {
						PacketDistributor.sendToServer(new PlayerStatsGUIButtonMessage(0, x, y, z));
						PlayerStatsGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				if (DisplayLevelingHealthLogicProcedure.execute())
					guiGraphics.blit(sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_pressed", imagebutton_pressed);
		this.addRenderableWidget(imagebutton_pressed);
		imagebutton_pressed3 = new ImageButton(this.leftPos + 234, this.topPos + 32, 20, 20,
				new WidgetSprites(ResourceLocation.parse("memory_of_the_past:textures/screens/pressed.png"), ResourceLocation.parse("memory_of_the_past:textures/screens/unpressed.png")), e -> {
					if (DisplayLevelingLogicAttackPowerProcedure.execute()) {
						PacketDistributor.sendToServer(new PlayerStatsGUIButtonMessage(1, x, y, z));
						PlayerStatsGUIButtonMessage.handleButtonAction(entity, 1, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				if (DisplayLevelingLogicAttackPowerProcedure.execute())
					guiGraphics.blit(sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_pressed3", imagebutton_pressed3);
		this.addRenderableWidget(imagebutton_pressed3);
		imagebutton_pressed1 = new ImageButton(this.leftPos + 234, this.topPos + 52, 20, 20,
				new WidgetSprites(ResourceLocation.parse("memory_of_the_past:textures/screens/pressed.png"), ResourceLocation.parse("memory_of_the_past:textures/screens/unpressed.png")), e -> {
					if (DisplayLevelingLogicAttackSpeedProcedure.execute()) {
						PacketDistributor.sendToServer(new PlayerStatsGUIButtonMessage(2, x, y, z));
						PlayerStatsGUIButtonMessage.handleButtonAction(entity, 2, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				if (DisplayLevelingLogicAttackSpeedProcedure.execute())
					guiGraphics.blit(sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_pressed1", imagebutton_pressed1);
		this.addRenderableWidget(imagebutton_pressed1);
		imagebutton_pressed2 = new ImageButton(this.leftPos + 234, this.topPos + 72, 20, 20,
				new WidgetSprites(ResourceLocation.parse("memory_of_the_past:textures/screens/pressed.png"), ResourceLocation.parse("memory_of_the_past:textures/screens/unpressed.png")), e -> {
					if (true) {
						PacketDistributor.sendToServer(new PlayerStatsGUIButtonMessage(3, x, y, z));
						PlayerStatsGUIButtonMessage.handleButtonAction(entity, 3, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_pressed2", imagebutton_pressed2);
		this.addRenderableWidget(imagebutton_pressed2);
		imagebutton_pressed4 = new ImageButton(this.leftPos + 234, this.topPos + 92, 20, 20,
				new WidgetSprites(ResourceLocation.parse("memory_of_the_past:textures/screens/pressed.png"), ResourceLocation.parse("memory_of_the_past:textures/screens/unpressed.png")), e -> {
					if (DisplayLevelingLogicMSProcedure.execute()) {
						PacketDistributor.sendToServer(new PlayerStatsGUIButtonMessage(4, x, y, z));
						PlayerStatsGUIButtonMessage.handleButtonAction(entity, 4, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				if (DisplayLevelingLogicMSProcedure.execute())
					guiGraphics.blit(sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_pressed4", imagebutton_pressed4);
		this.addRenderableWidget(imagebutton_pressed4);
		imagebutton_pressed5 = new ImageButton(this.leftPos + 234, this.topPos + 112, 20, 20,
				new WidgetSprites(ResourceLocation.parse("memory_of_the_past:textures/screens/pressed.png"), ResourceLocation.parse("memory_of_the_past:textures/screens/unpressed.png")), e -> {
					if (DisplayLevelingLogicFortitudeProcedure.execute()) {
						PacketDistributor.sendToServer(new PlayerStatsGUIButtonMessage(5, x, y, z));
						PlayerStatsGUIButtonMessage.handleButtonAction(entity, 5, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				if (DisplayLevelingLogicFortitudeProcedure.execute())
					guiGraphics.blit(sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_pressed5", imagebutton_pressed5);
		this.addRenderableWidget(imagebutton_pressed5);
		imagebutton_pressed6 = new ImageButton(this.leftPos + 234, this.topPos + 137, 20, 20,
				new WidgetSprites(ResourceLocation.parse("memory_of_the_past:textures/screens/pressed.png"), ResourceLocation.parse("memory_of_the_past:textures/screens/unpressed.png")), e -> {
					if (DisplayLevelingLogicExplorationProcedure.execute()) {
						PacketDistributor.sendToServer(new PlayerStatsGUIButtonMessage(6, x, y, z));
						PlayerStatsGUIButtonMessage.handleButtonAction(entity, 6, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				if (DisplayLevelingLogicExplorationProcedure.execute())
					guiGraphics.blit(sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_pressed6", imagebutton_pressed6);
		this.addRenderableWidget(imagebutton_pressed6);
	}

	private void renderEntityInInventoryFollowsAngle(GuiGraphics guiGraphics, int x, int y, int scale, float angleXComponent, float angleYComponent, LivingEntity entity) {
		Quaternionf pose = new Quaternionf().rotateZ((float) Math.PI);
		Quaternionf cameraOrientation = new Quaternionf().rotateX(angleYComponent * 20 * ((float) Math.PI / 180F));
		pose.mul(cameraOrientation);
		float f2 = entity.yBodyRot;
		float f3 = entity.getYRot();
		float f4 = entity.getXRot();
		float f5 = entity.yHeadRotO;
		float f6 = entity.yHeadRot;
		entity.yBodyRot = 180.0F + angleXComponent * 20.0F;
		entity.setYRot(180.0F + angleXComponent * 40.0F);
		entity.setXRot(-angleYComponent * 20.0F);
		entity.yHeadRot = entity.getYRot();
		entity.yHeadRotO = entity.getYRot();
		InventoryScreen.renderEntityInInventory(guiGraphics, x, y, scale, new Vector3f(0, 0, 0), pose, cameraOrientation, entity);
		entity.yBodyRot = f2;
		entity.setYRot(f3);
		entity.setXRot(f4);
		entity.yHeadRotO = f5;
		entity.yHeadRot = f6;
	}
}
