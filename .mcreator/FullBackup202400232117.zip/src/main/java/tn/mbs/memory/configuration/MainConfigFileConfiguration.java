package tn.mbs.memory.configuration;

import net.neoforged.neoforge.common.ModConfigSpec;

public class MainConfigFileConfiguration {
	public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
	public static final ModConfigSpec SPEC;
	public static final ModConfigSpec.ConfigValue<Boolean> DISPLAY_LEVEL;
	public static final ModConfigSpec.ConfigValue<Boolean> DISPLAY_XP;
	public static final ModConfigSpec.ConfigValue<Boolean> DISPLAY_POINTS;
	public static final ModConfigSpec.ConfigValue<Double> LESSER_XP_VALUE;
	public static final ModConfigSpec.ConfigValue<Double> BETTER_XP_VALUE;
	public static final ModConfigSpec.ConfigValue<Double> GREATER_XP_VALUE;
	public static final ModConfigSpec.ConfigValue<Double> LEVEL_PER_ORB;
	public static final ModConfigSpec.ConfigValue<Double> SCALE_FACTOR;
	public static final ModConfigSpec.ConfigValue<Double> POINTS_PER_LEVEL;
	public static final ModConfigSpec.ConfigValue<Boolean> ENABLEDROPS;
	public static final ModConfigSpec.ConfigValue<Boolean> ONDEATHRESET;
	public static final ModConfigSpec.ConfigValue<Double> MAXPLAYERLEVEL;
	public static final ModConfigSpec.ConfigValue<Double> BONUS_EXPERIENCE_FACTOR;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_1;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_2;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_3;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_4;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_5;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_6;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_7;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_8;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_9;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_10;
	public static final ModConfigSpec.ConfigValue<Double> INIT_VAL_STARTING_LEVEL;
	public static final ModConfigSpec.ConfigValue<Double> LEVEL_INTERVAL_FIRST;
	public static final ModConfigSpec.ConfigValue<Double> LEVEL_INTERVAL_SCALE_FIRST;
	public static final ModConfigSpec.ConfigValue<Double> LEVEL_INTERVAL_SECOND;
	public static final ModConfigSpec.ConfigValue<Double> LEVEL_INTERVAL_SCALE_SECOND;
	public static final ModConfigSpec.ConfigValue<Double> LEVEL_INTERVAL_SCALE_AFTER;
	public static final ModConfigSpec.ConfigValue<Double> STARTING_XP_LEVEL;
	public static final ModConfigSpec.ConfigValue<String> GLOBAL_STATS_UI_COLOR;
	static {
		BUILDER.push("HUD Overlay");
		DISPLAY_LEVEL = BUILDER.define("display_level_overlay", true);
		DISPLAY_XP = BUILDER.define("display_xp_overlay", true);
		DISPLAY_POINTS = BUILDER.define("display_points_overlay", true);
		BUILDER.pop();
		BUILDER.push("Leveling Config");
		LESSER_XP_VALUE = BUILDER.define("lesser_experience_value", (double) 20);
		BETTER_XP_VALUE = BUILDER.define("better_experience_value", (double) 200);
		GREATER_XP_VALUE = BUILDER.define("greater_experience_value", (double) 2000);
		LEVEL_PER_ORB = BUILDER.define("level_per_orb", (double) 1);
		SCALE_FACTOR = BUILDER.define("scale_factor", (double) 30);
		POINTS_PER_LEVEL = BUILDER.define("points_per_level", (double) 1);
		ENABLEDROPS = BUILDER.define("enableDrops", true);
		ONDEATHRESET = BUILDER.define("onDeathReset", false);
		MAXPLAYERLEVEL = BUILDER.define("maxPlayerLevel", (double) 500);
		BUILDER.pop();
		BUILDER.push("Artifacts Settings");
		BONUS_EXPERIENCE_FACTOR = BUILDER.define("bonus_experience_factor", (double) 1.4);
		BUILDER.pop();
		BUILDER.push("Initial Starting Values");
		INIT_VAL_1 = BUILDER.define("init_val_attribute_one", (double) 20);
		INIT_VAL_2 = BUILDER.define("init_val_attribute_two", (double) 2);
		INIT_VAL_3 = BUILDER.define("init_val_attribute_three", (double) 4);
		INIT_VAL_4 = BUILDER.define("init_val_attribute_forth", (double) 0);
		INIT_VAL_5 = BUILDER.define("init_val_attribute_fifth", (double) 20);
		INIT_VAL_6 = BUILDER.define("init_val_attribute_sixth", (double) 0);
		INIT_VAL_7 = BUILDER.define("init_val_attribute_seventh", (double) 0);
		INIT_VAL_8 = BUILDER.define("init_val_attribute_eight", (double) 0);
		INIT_VAL_9 = BUILDER.define("init_val_attribute_nine", (double) 0);
		INIT_VAL_10 = BUILDER.define("init_val_attribute_ten", (double) 0);
		INIT_VAL_STARTING_LEVEL = BUILDER.define("init_val_starting_level", (double) 1);
		BUILDER.pop();
		BUILDER.push("Leveling Scale");
		LEVEL_INTERVAL_FIRST = BUILDER.define("level_interval_first", (double) 20000);
		LEVEL_INTERVAL_SCALE_FIRST = BUILDER.define("level_interval_scale_first", (double) 1.1);
		LEVEL_INTERVAL_SECOND = BUILDER.define("level_interval_second", (double) 100000);
		LEVEL_INTERVAL_SCALE_SECOND = BUILDER.define("level_interval_scale_second", (double) 1.02);
		LEVEL_INTERVAL_SCALE_AFTER = BUILDER.define("level_interval_scale_after", (double) 1.001);
		STARTING_XP_LEVEL = BUILDER.define("starting_xp_level", (double) 90);
		BUILDER.pop();
		BUILDER.push("Colors");
		GLOBAL_STATS_UI_COLOR = BUILDER.define("global_stats_ui_color", "§6");
		BUILDER.pop();

		SPEC = BUILDER.build();
	}

}
