package tn.mbs.memory.init;

import tn.mbs.memory.configuration.MechanicsConfigConfiguration;
import tn.mbs.memory.configuration.MainConfigFileConfiguration;
import tn.mbs.memory.configuration.LevelUpRewardsConfigConfiguration;
import tn.mbs.memory.configuration.DropRateConfigFileConfiguration;
import tn.mbs.memory.MemoryOfThePastMod;

import net.neoforged.fml.event.lifecycle.FMLConstructModEvent;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.ModContainer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.IEventBus;

@Mod(MemoryOfThePastMod.MODID)
@EventBusSubscriber(modid = MemoryOfThePastMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public class MemoryOfThePastModConfigs {
	private static ModContainer modContainer;

	public MemoryOfThePastModConfigs(IEventBus modEventBus, ModContainer container) {
		setModContainer(container);
	}

	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			modContainer.registerConfig(ModConfig.Type.COMMON, MainConfigFileConfiguration.SPEC, "motp/main_config.toml");
			modContainer.registerConfig(ModConfig.Type.COMMON, DropRateConfigFileConfiguration.SPEC, "motp/drop_rate_config.toml");
			modContainer.registerConfig(ModConfig.Type.COMMON, LevelUpRewardsConfigConfiguration.SPEC, "motp/levelup_rewards.toml");
			modContainer.registerConfig(ModConfig.Type.COMMON, MechanicsConfigConfiguration.SPEC, "motp/attributes_config.toml");
		});
	}

	public static void setModContainer(ModContainer container) {
		modContainer = container;
	}
}
