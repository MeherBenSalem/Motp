package tn.mbs.memory.procedures;

import tn.mbs.memory.network.MemoryOfThePastModVariables;
import tn.mbs.memory.configuration.MainConfigFileConfiguration;

import net.minecraft.world.entity.Entity;

public class AddAttackDamagePointsProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).SparePoints >= 1 && entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).attack_damage < (double) MainConfigFileConfiguration.MAX_AP_LEVEL.get()) {
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.SparePoints = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).SparePoints - 1;
				_vars.syncPlayerVariables(entity);
			}
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.attack_damage = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).attack_damage + (double) MainConfigFileConfiguration.AP_VALUE_PER_LEVEL.get();
				_vars.syncPlayerVariables(entity);
			}
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.Level = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).Level + 1;
				_vars.syncPlayerVariables(entity);
			}
			OnPlayerSpawnProcedure.execute(entity);
		}
	}
}
