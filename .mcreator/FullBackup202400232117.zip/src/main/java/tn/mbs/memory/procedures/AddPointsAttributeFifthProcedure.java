package tn.mbs.memory.procedures;

import tn.mbs.memory.network.MemoryOfThePastModVariables;
import tn.mbs.memory.configuration.MechanicsConfigConfiguration;

import net.minecraft.world.entity.Entity;

public class AddPointsAttributeFifthProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).SparePoints >= 1 && entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).attribute_5 < (double) MechanicsConfigConfiguration.MAX_LEVEL_ATT_5.get()) {
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.SparePoints = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).SparePoints - 1;
				_vars.syncPlayerVariables(entity);
			}
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.Level = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).Level + 1;
				_vars.syncPlayerVariables(entity);
			}
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.attribute_5 = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).attribute_5 + (double) MechanicsConfigConfiguration.BASE_VALUE_PER_POINT_5.get();
				_vars.syncPlayerVariables(entity);
			}
			OnPlayerSpawnProcedure.execute(entity);
		}
	}
}
