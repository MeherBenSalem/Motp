package tn.mbs.memory.procedures;

import tn.mbs.memory.network.MemoryOfThePastModVariables;

import net.minecraft.world.entity.Entity;
import net.minecraft.commands.CommandSourceStack;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class AddPointsCmdProcedure {
	public static void execute(CommandContext<CommandSourceStack> arguments, Entity entity) {
		if (entity == null)
			return;
		{
			MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
			_vars.SparePoints = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).SparePoints + DoubleArgumentType.getDouble(arguments, "count");
			_vars.syncPlayerVariables(entity);
		}
		if (DoubleArgumentType.getDouble(arguments, "attribute_Id") == 1) {
			for (int index0 = 0; index0 < (int) DoubleArgumentType.getDouble(arguments, "count"); index0++) {
				AddPointsProcedureProcedure.execute(entity);
			}
		} else if (DoubleArgumentType.getDouble(arguments, "attribute_Id") == 2) {
			for (int index1 = 0; index1 < (int) DoubleArgumentType.getDouble(arguments, "count"); index1++) {
				AddAttackDamagePointsProcedure.execute(entity);
			}
		} else if (DoubleArgumentType.getDouble(arguments, "attribute_Id") == 3) {
			for (int index2 = 0; index2 < (int) DoubleArgumentType.getDouble(arguments, "count"); index2++) {
				AddAttackSpeedPointsProcedure.execute(entity);
			}
		} else if (DoubleArgumentType.getDouble(arguments, "attribute_Id") == 4) {
			for (int index3 = 0; index3 < (int) DoubleArgumentType.getDouble(arguments, "count"); index3++) {
				AddAromrPointsProcedure.execute(entity);
			}
		} else if (DoubleArgumentType.getDouble(arguments, "attribute_Id") == 5) {
			for (int index4 = 0; index4 < (int) DoubleArgumentType.getDouble(arguments, "count"); index4++) {
				AddMvPointsProcedure.execute(entity);
			}
		} else if (DoubleArgumentType.getDouble(arguments, "attribute_Id") == 6) {
			for (int index5 = 0; index5 < (int) DoubleArgumentType.getDouble(arguments, "count"); index5++) {
				AddResistancePointsProcedure.execute(entity);
			}
		} else {
			for (int index6 = 0; index6 < (int) DoubleArgumentType.getDouble(arguments, "count"); index6++) {
				AddExplorationPointsProcedure.execute(entity);
			}
		}
	}
}
