package tn.mbs.memory.procedures;

import tn.mbs.memory.network.MemoryOfThePastModVariables;
import tn.mbs.memory.init.MemoryOfThePastModItems;
import tn.mbs.memory.configuration.MainConfigFileConfiguration;
import tn.mbs.memory.configuration.DropRateConfigFileConfiguration;
import tn.mbs.memory.MemoryOfThePastMod;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

public class GiveXpNoDropProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double AddedXp = 0;
		if ((sourceentity.level().dimension()) == Level.OVERWORLD) {
			if (Mth.nextInt(RandomSource.create(), 0, 99) < (double) DropRateConfigFileConfiguration.OW_LESSER_RATE.get()) {
				AddedXp = (double) MainConfigFileConfiguration.LESSER_XP_VALUE.get();
			} else if (Mth.nextInt(RandomSource.create(), 0, 99) < (double) DropRateConfigFileConfiguration.OW_BETTER_RATE.get()) {
				AddedXp = (double) MainConfigFileConfiguration.BETTER_XP_VALUE.get();
			} else if (Mth.nextInt(RandomSource.create(), 0, 99) < (double) DropRateConfigFileConfiguration.OW_GREATER_RATE.get()) {
				AddedXp = (double) MainConfigFileConfiguration.GREATER_XP_VALUE.get();
			}
		} else if ((sourceentity.level().dimension()) == Level.NETHER) {
			if (Mth.nextInt(RandomSource.create(), 0, 99) < (double) DropRateConfigFileConfiguration.NETHER_LESSER_RATE.get()) {
				AddedXp = (double) MainConfigFileConfiguration.LESSER_XP_VALUE.get();
			} else if (Mth.nextInt(RandomSource.create(), 0, 99) < (double) DropRateConfigFileConfiguration.NETHER_BETTER_RATE.get()) {
				AddedXp = (double) MainConfigFileConfiguration.BETTER_XP_VALUE.get();
			} else if (Mth.nextInt(RandomSource.create(), 0, 99) < (double) DropRateConfigFileConfiguration.NETHER_GREATER_RATE.get()) {
				AddedXp = (double) MainConfigFileConfiguration.GREATER_XP_VALUE.get();
			}
		} else if ((sourceentity.level().dimension()) == Level.END) {
			if (Mth.nextInt(RandomSource.create(), 0, 99) < (double) DropRateConfigFileConfiguration.END_LESSER_RATE.get()) {
				AddedXp = (double) MainConfigFileConfiguration.LESSER_XP_VALUE.get();
			} else if (Mth.nextInt(RandomSource.create(), 0, 99) < (double) DropRateConfigFileConfiguration.END_BETTER_RATE.get()) {
				AddedXp = (double) MainConfigFileConfiguration.BETTER_XP_VALUE.get();
			} else if (Mth.nextInt(RandomSource.create(), 0, 99) < (double) DropRateConfigFileConfiguration.END_GREATER_RATE.get()) {
				AddedXp = (double) MainConfigFileConfiguration.GREATER_XP_VALUE.get();
			}
		}
		if ((sourceentity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(MemoryOfThePastModItems.EXPERIENCE_ENHANCER_ARTIFACT.get())) : false)
				&& sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).exploration >= 4) {
			AddedXp = (double) MainConfigFileConfiguration.GREATER_XP_VALUE.get() * (double) MainConfigFileConfiguration.BONUS_EXPERIENCE_FACTOR.get();
		}
		{
			MemoryOfThePastModVariables.PlayerVariables _vars = sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
			_vars.currentXpTLevel = sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).currentXpTLevel + AddedXp * (1
					+ Math.round((sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).SparePoints + sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).Level) / (double) MainConfigFileConfiguration.SCALE_FACTOR.get()));
			_vars.syncPlayerVariables(sourceentity);
		}
		MemoryOfThePastMod.LOGGER.info(sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).currentXpTLevel);
		while (sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).currentXpTLevel >= sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).nextevelXp) {
			MemoryOfThePastMod.LOGGER.info(sourceentity);
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.currentXpTLevel = sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).currentXpTLevel - sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).nextevelXp;
				_vars.syncPlayerVariables(sourceentity);
			}
			MemoryOfThePastMod.LOGGER.info(sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).currentXpTLevel);
			LevelUpProcedureAutoLevelProcedure.execute(world, x, y, z, entity, sourceentity);
		}
	}
}
