package tn.mbs.memory.procedures;

import tn.mbs.memory.network.MemoryOfThePastModVariables;
import tn.mbs.memory.configuration.MainConfigFileConfiguration;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

public class LevelUpProcedureAutoLevelProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		CheclLevelupRewardsAutoProcedure.execute(world, x, y, z, sourceentity);
		if (sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).nextevelXp <= (double) MainConfigFileConfiguration.LEVEL_INTERVAL_FIRST.get()) {
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.nextevelXp = Math.round(sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).nextevelXp * (double) MainConfigFileConfiguration.LEVEL_INTERVAL_SCALE_FIRST.get());
				_vars.syncPlayerVariables(sourceentity);
			}
		} else if (sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).nextevelXp <= (double) MainConfigFileConfiguration.LEVEL_INTERVAL_SECOND.get()) {
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.nextevelXp = Math.round(sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).nextevelXp * (double) MainConfigFileConfiguration.LEVEL_INTERVAL_SCALE_SECOND.get());
				_vars.syncPlayerVariables(sourceentity);
			}
		} else {
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.nextevelXp = Math.round(entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).nextevelXp * (double) MainConfigFileConfiguration.LEVEL_INTERVAL_SCALE_AFTER.get());
				_vars.syncPlayerVariables(sourceentity);
			}
		}
		{
			MemoryOfThePastModVariables.PlayerVariables _vars = sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
			_vars.SparePoints = sourceentity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).SparePoints + (double) MainConfigFileConfiguration.POINTS_PER_LEVEL.get();
			_vars.syncPlayerVariables(sourceentity);
		}
	}
}
