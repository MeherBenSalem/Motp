package tn.mbs.memory.procedures;

import tn.mbs.memory.network.MemoryOfThePastModVariables;
import tn.mbs.memory.init.MemoryOfThePastModItems;
import tn.mbs.memory.configuration.MainConfigFileConfiguration;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

public class ManageLevelUpProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		double AddedXp = 0;
		if (itemstack.getItem() == MemoryOfThePastModItems.LESSER_DROP_OF_KNOWLEDGE.get()) {
			if (entity instanceof Player _player) {
				ItemStack _stktoremove = new ItemStack(MemoryOfThePastModItems.LESSER_DROP_OF_KNOWLEDGE.get());
				_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
			}
			AddedXp = (double) MainConfigFileConfiguration.LESSER_XP_VALUE.get();
		}
		if (itemstack.getItem() == MemoryOfThePastModItems.BETTER_DROP_OF_KNOWLEDGE.get()) {
			if (entity instanceof Player _player) {
				ItemStack _stktoremove = new ItemStack(MemoryOfThePastModItems.BETTER_DROP_OF_KNOWLEDGE.get());
				_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
			}
			AddedXp = (double) MainConfigFileConfiguration.BETTER_XP_VALUE.get();
		}
		if (itemstack.getItem() == MemoryOfThePastModItems.GREAT_DROP_OF_KNOWLEDGE.get()) {
			if (entity instanceof Player _player) {
				ItemStack _stktoremove = new ItemStack(MemoryOfThePastModItems.GREAT_DROP_OF_KNOWLEDGE.get());
				_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
			}
			AddedXp = (double) MainConfigFileConfiguration.GREATER_XP_VALUE.get();
		}
		if ((entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(MemoryOfThePastModItems.EXPERIENCE_ENHANCER_ARTIFACT.get())) : false)
				&& entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).attribute_7 >= 4) {
			AddedXp = AddedXp * (double) MainConfigFileConfiguration.BONUS_EXPERIENCE_FACTOR.get();
		}
		{
			MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
			_vars.currentXpTLevel = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).currentXpTLevel + AddedXp
					* (1 + Math.floor((entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).SparePoints + entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).Level) / (double) MainConfigFileConfiguration.SCALE_FACTOR.get()));
			_vars.syncPlayerVariables(entity);
		}
		if (entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).Level >= (double) MainConfigFileConfiguration.MAXPLAYERLEVEL.get()) {
			return;
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.experience_orb.pickup")), SoundSource.NEUTRAL, 1, 1);
			} else {
				_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.experience_orb.pickup")), SoundSource.NEUTRAL, 1, 1, false);
			}
		}
		while (entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).currentXpTLevel >= entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).nextevelXp) {
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.currentXpTLevel = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).currentXpTLevel - entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).nextevelXp;
				_vars.syncPlayerVariables(entity);
			}
			LevelUpProcedureProcedure.execute(world, x, y, z, entity);
		}
	}
}
