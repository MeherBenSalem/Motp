package tn.mbs.memory.procedures;

import tn.mbs.memory.network.MemoryOfThePastModVariables;
import tn.mbs.memory.configuration.MechanicsConfigConfiguration;
import tn.mbs.memory.configuration.MainConfigFileConfiguration;

import org.checkerframework.checker.units.qual.s;

import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import javax.annotation.Nullable;

@EventBusSubscriber
public class OnPlayerSpawnProcedure {
	@SubscribeEvent
	public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		String stringCommand = "";
		double commandParam = 0;
		if (entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).Level <= 0) {
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.max_health = (double) MainConfigFileConfiguration.INIT_VAL_1.get();
				_vars.syncPlayerVariables(entity);
			}
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.knockback_resistance = (double) MainConfigFileConfiguration.INIT_VAL_6.get();
				_vars.syncPlayerVariables(entity);
			}
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.movement_speed = (double) MainConfigFileConfiguration.INIT_VAL_5.get();
				_vars.syncPlayerVariables(entity);
			}
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.attack_damage = (double) MainConfigFileConfiguration.INIT_VAL_2.get();
				_vars.syncPlayerVariables(entity);
			}
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.armor = (double) MainConfigFileConfiguration.INIT_VAL_4.get();
				_vars.syncPlayerVariables(entity);
			}
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.attack_speed = (double) MainConfigFileConfiguration.INIT_VAL_3.get();
				_vars.syncPlayerVariables(entity);
			}
			{
				MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
				_vars.exploration = (double) MainConfigFileConfiguration.INIT_VAL_7.get();
				_vars.syncPlayerVariables(entity);
			}
			if (entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).SparePoints <= 0) {
				{
					MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
					_vars.SparePoints = (double) MainConfigFileConfiguration.INIT_VAL_STARTING_LEVEL.get();
					_vars.syncPlayerVariables(entity);
				}
			}
		} else {
			if (entity.getPersistentData().getDouble("motp_att_1") > entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).max_health) {
				{
					MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
					_vars.max_health = entity.getPersistentData().getDouble("motp_att_1");
					_vars.syncPlayerVariables(entity);
				}
			}
			if (entity.getPersistentData().getDouble("motp_att_2") > entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).attack_damage) {
				{
					MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
					_vars.attack_damage = entity.getPersistentData().getDouble("motp_att_2");
					_vars.syncPlayerVariables(entity);
				}
			}
			if (entity.getPersistentData().getDouble("motp_att_3") > entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).attack_speed) {
				{
					MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
					_vars.attack_speed = entity.getPersistentData().getDouble("motp_att_3");
					_vars.syncPlayerVariables(entity);
				}
			}
			if (entity.getPersistentData().getDouble("motp_att_4") > entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).armor) {
				{
					MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
					_vars.armor = entity.getPersistentData().getDouble("motp_att_4");
					_vars.syncPlayerVariables(entity);
				}
			}
			if (entity.getPersistentData().getDouble("motp_att_5") > entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).movement_speed) {
				{
					MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
					_vars.movement_speed = entity.getPersistentData().getDouble("motp_att_5");
					_vars.syncPlayerVariables(entity);
				}
			}
			if (entity.getPersistentData().getDouble("motp_att_6") > entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).knockback_resistance) {
				{
					MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
					_vars.knockback_resistance = entity.getPersistentData().getDouble("motp_att_6");
					_vars.syncPlayerVariables(entity);
				}
			}
			if (entity.getPersistentData().getDouble("motp_att_7") > entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).exploration) {
				{
					MemoryOfThePastModVariables.PlayerVariables _vars = entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES);
					_vars.exploration = entity.getPersistentData().getDouble("motp_att_7");
					_vars.syncPlayerVariables(entity);
				}
			}
		}
		entity.getPersistentData().putDouble("motp_att_1", entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).max_health);
		entity.getPersistentData().putDouble("motp_att_6", entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).knockback_resistance);
		entity.getPersistentData().putDouble("motp_att_5", entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).movement_speed);
		entity.getPersistentData().putDouble("motp_att_2", entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).attack_damage);
		entity.getPersistentData().putDouble("motp_att_4", entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).armor);
		entity.getPersistentData().putDouble("motp_att_3", entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).attack_speed);
		entity.getPersistentData().putDouble("motp_att_7", entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).exploration);
		entity.getPersistentData().putDouble("motp_level", entity.getData(MemoryOfThePastModVariables.PLAYER_VARIABLES).Level);
		for (String stringiterator : MechanicsConfigConfiguration.CMD_ATT_1.get()) {
			stringCommand = stringiterator;
			if (stringCommand.contains("[param]") && stringCommand.contains("[paramEnd]")) {
				commandParam = Math.round(new Object() {
					double convert(String s) {
						try {
							return Double.parseDouble(s.trim());
						} catch (Exception e) {
						}
						return 0;
					}
				}.convert(stringCommand.substring((int) (stringCommand.indexOf("[param]") + 7), (int) stringCommand.indexOf("[paramEnd]"))));
				stringCommand = stringCommand.substring(0, (int) (stringCommand.indexOf("(variable)") + 10));
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_1") * commandParam);
			} else {
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_1"));
			}
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
							_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), stringCommand);
				}
			}
		}
		for (String stringiterator : MechanicsConfigConfiguration.CMD_ATT_2.get()) {
			stringCommand = stringiterator;
			if (stringCommand.contains("[param]") && stringCommand.contains("[paramEnd]")) {
				commandParam = Math.round(new Object() {
					double convert(String s) {
						try {
							return Double.parseDouble(s.trim());
						} catch (Exception e) {
						}
						return 0;
					}
				}.convert(stringCommand.substring((int) (stringCommand.indexOf("[param]") + 7), (int) stringCommand.indexOf("[paramEnd]"))));
				stringCommand = stringCommand.substring(0, (int) (stringCommand.indexOf("(variable)") + 10));
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_2") * commandParam);
			} else {
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_2"));
			}
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
							_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), stringCommand);
				}
			}
		}
		for (String stringiterator : MechanicsConfigConfiguration.CMD_ATT_3.get()) {
			stringCommand = stringiterator;
			if (stringCommand.contains("[param]") && stringCommand.contains("[paramEnd]")) {
				commandParam = Math.round(new Object() {
					double convert(String s) {
						try {
							return Double.parseDouble(s.trim());
						} catch (Exception e) {
						}
						return 0;
					}
				}.convert(stringCommand.substring((int) (stringCommand.indexOf("[param]") + 7), (int) stringCommand.indexOf("[paramEnd]"))));
				stringCommand = stringCommand.substring(0, (int) (stringCommand.indexOf("(variable)") + 10));
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_3") * commandParam);
			} else {
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_3"));
			}
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
							_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), stringCommand);
				}
			}
		}
		for (String stringiterator : MechanicsConfigConfiguration.CMD_ATT_4.get()) {
			stringCommand = stringiterator;
			if (stringCommand.contains("[param]") && stringCommand.contains("[paramEnd]")) {
				commandParam = Math.round(new Object() {
					double convert(String s) {
						try {
							return Double.parseDouble(s.trim());
						} catch (Exception e) {
						}
						return 0;
					}
				}.convert(stringCommand.substring((int) (stringCommand.indexOf("[param]") + 7), (int) stringCommand.indexOf("[paramEnd]"))));
				stringCommand = stringCommand.substring(0, (int) (stringCommand.indexOf("(variable)") + 10));
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("cmd_att_4") * commandParam);
			} else {
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("cmd_att_4"));
			}
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
							_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), stringCommand);
				}
			}
		}
		for (String stringiterator : MechanicsConfigConfiguration.CMD_ATT_5.get()) {
			stringCommand = stringiterator;
			if (stringCommand.contains("[param]") && stringCommand.contains("[paramEnd]")) {
				commandParam = Math.round(new Object() {
					double convert(String s) {
						try {
							return Double.parseDouble(s.trim());
						} catch (Exception e) {
						}
						return 0;
					}
				}.convert(stringCommand.substring((int) (stringCommand.indexOf("[param]") + 7), (int) stringCommand.indexOf("[paramEnd]"))));
				stringCommand = stringCommand.substring(0, (int) (stringCommand.indexOf("(variable)") + 10));
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_5") * commandParam);
			} else {
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_5"));
			}
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
							_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), stringCommand);
				}
			}
		}
		for (String stringiterator : MechanicsConfigConfiguration.CMD_ATT_6.get()) {
			stringCommand = stringiterator;
			if (stringCommand.contains("[param]") && stringCommand.contains("[paramEnd]")) {
				commandParam = Math.round(new Object() {
					double convert(String s) {
						try {
							return Double.parseDouble(s.trim());
						} catch (Exception e) {
						}
						return 0;
					}
				}.convert(stringCommand.substring((int) (stringCommand.indexOf("[param]") + 7), (int) stringCommand.indexOf("[paramEnd]"))));
				stringCommand = stringCommand.substring(0, (int) (stringCommand.indexOf("(variable)") + 10));
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_6") * commandParam);
			} else {
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_6"));
			}
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
							_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), stringCommand);
				}
			}
		}
		for (String stringiterator : MechanicsConfigConfiguration.CMD_ATT_7.get()) {
			stringCommand = stringiterator;
			if (stringCommand.contains("[param]") && stringCommand.contains("[paramEnd]")) {
				commandParam = Math.round(new Object() {
					double convert(String s) {
						try {
							return Double.parseDouble(s.trim());
						} catch (Exception e) {
						}
						return 0;
					}
				}.convert(stringCommand.substring((int) (stringCommand.indexOf("[param]") + 7), (int) stringCommand.indexOf("[paramEnd]"))));
				stringCommand = stringCommand.substring(0, (int) (stringCommand.indexOf("(variable)") + 10));
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_7") * commandParam);
			} else {
				stringCommand = stringCommand.replace("(variable)", "" + entity.getPersistentData().getDouble("motp_att_7"));
			}
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
							_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), stringCommand);
				}
			}
		}
	}
}
